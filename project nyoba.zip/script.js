document.addEventListener("DOMContentLoaded", function() {
    loadData();
});

document.getElementById("hadir").addEventListener("click", function() {
    let nama = document.getElementById("nama").value.trim();

    if (nama === "") {
        alert("Harap isi nama!");
        return;
    }

    let waktu = new Date().toLocaleString();
    let dataHadir = JSON.parse(localStorage.getItem("dataHadir")) || [];

    // Cek apakah nama sudah ada
    let index = dataHadir.findIndex(item => item.nama.toLowerCase() === nama.toLowerCase());

    if (index !== -1) {
        // Tambah 1 poin jika nama sudah ada
        dataHadir[index].poin += 1;
        dataHadir[index].waktu = waktu;
    } else {
        // Jika nama baru, tambahkan dengan 1 poin
        dataHadir.push({ nama, poin: 1, waktu });
    }

    localStorage.setItem("dataHadir", JSON.stringify(dataHadir));

    updateTable();
    document.getElementById("nama").value = "";
});

document.getElementById("reset").addEventListener("click", function() {
    document.getElementById("nama").value = "";
});

document.getElementById("hapusSemua").addEventListener("click", function() {
    if (confirm("Apakah Anda yakin ingin menghapus semua data?")) {
        localStorage.removeItem("dataHadir");
        updateTable();
    }
});

function loadData() {
    updateTable();
}

function updateTable() {
    let tabel = document.getElementById("data-hadir");
    tabel.innerHTML = ""; // Kosongkan tabel sebelum menambahkan data baru

    let dataHadir = JSON.parse(localStorage.getItem("dataHadir")) || [];

    dataHadir.forEach(item => {
        let row = tabel.insertRow();
        row.innerHTML = `<td>${item.nama}</td><td>${item.poin}</td><td>${item.waktu}</td>`;
    });
}